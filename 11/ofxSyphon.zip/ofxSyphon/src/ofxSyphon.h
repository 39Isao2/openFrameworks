/*
 *  ofxSyphonServer.h
 *  syphonTest
 *
 *  Created by astellato,vade,bangnoise on 11/6/10.
 *
 *  http://syphon.v002.info/license.php
 */

#include "ofMain.h"
#import "ofxSyphonClient.h"
#import "ofxSyphonServer.h"
#import "ofxSyphonServerDirectory.h"
