// Copyright (C) 2006  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_ALL_CONSOLe_
#define DLIB_ALL_CONSOLe_

#error "This file has been replaced.  Instead you should add dlib/all/source.cpp to your project"

#endif // DLIB_ALL_CONSOLe_

