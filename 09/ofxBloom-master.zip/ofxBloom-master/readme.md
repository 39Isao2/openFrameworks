# ofxBloom

|   |   |
| ---- | ---- |
| Bloom |  ![ss](https://github.com/P-A-N/ofxBloom/blob/master/bloom.png)  |
| None |  ![ss](https://github.com/P-A-N/ofxBloom/blob/master/none.png)  |


## Tested on
* 0.9.8 and 0.10.1
* OpenGL 1.2 ~ 4.5
* Both of Mac and Windows


## Todo
* write more detail
