#include "ofApp.h"

int main() {
	ofSetupOpenGL(1025, 512, OF_WINDOW);
	ofRunApp(new ofApp());
}
