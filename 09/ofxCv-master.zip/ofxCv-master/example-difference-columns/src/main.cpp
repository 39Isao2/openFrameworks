#include "ofApp.h"

int main() {
	ofSetupOpenGL(320 * 2, 240, OF_WINDOW);
	ofRunApp(new ofApp());
}
