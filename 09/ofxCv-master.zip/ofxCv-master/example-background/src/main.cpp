#include "ofApp.h"

int main() {
	ofSetupOpenGL(640 * 2, 480, OF_WINDOW);
	ofRunApp(new ofApp());
}
